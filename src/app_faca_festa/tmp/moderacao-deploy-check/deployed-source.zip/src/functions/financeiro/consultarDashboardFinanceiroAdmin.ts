import { onCall } from "../../shared/callableComMfa";
import { admin } from "../../shared/firebaseAdmin";
import { exigirUsuarioAutenticado, exigirTipo } from "../../shared/auth";
import { carregarMapaDocs } from "../../shared/carregarMapaDocs";
import { mapearEmLotes } from "../../shared/mapearEmLotes";
import { COL_REPASSES } from "../../services/financeiro/intermediacaoPersistenciaService";
import { divisaoContrato } from "../../services/financeiro/liberacaoRepasseService";
import {
  agregarDashboardAdmin,
  centavosDeOrcamento,
  FatoComercial,
  FatoComissao,
} from "../../services/financeiro/dashboardAdminService";
import {
  LinhaContratacaoAdmin,
  resolverLinhaContratacao,
  rotuloEstadoExecucao,
} from "../../services/financeiro/contratacaoIdentidadeService";

const REGION = "southamerica-east1";
const LIMITE_ORCAMENTOS = 500;

type ValoresContratacao = {
  liquido_fornecedor_centavos: number | null;
  comissao_centavos: number | null;
  comissao_absorvida: boolean;
  comissao_recebida_centavos: number | null;
  vencimento_comissao: string | null;
  repasse_confirmado_centavos: number;
  ultimo_repasse_confirmado_em: string | null;
};

async function lerPorContrato(
  colecao: FirebaseFirestore.CollectionReference,
  ids: string[],
  campos: string[],
) {
  const lotes: string[][] = [];
  for (let i = 0; i < ids.length; i += 30) lotes.push(ids.slice(i, i + 30));
  const consultas = await mapearEmLotes(lotes, (lote) =>
    colecao.where("id_contrato", "in", lote).select("id_contrato", ...campos).get(),
  );
  const porContrato = new Map<string, FirebaseFirestore.DocumentData[]>();
  for (const consulta of consultas) {
    for (const doc of consulta.docs) {
      const dados = doc.data();
      const lista = porContrato.get(dados.id_contrato) ?? [];
      lista.push(dados);
      porContrato.set(dados.id_contrato, lista);
    }
  }
  return porContrato;
}

function texto(v: unknown): string {
  return typeof v === "string" ? v.trim() : "";
}

function parseData(v: unknown): string | null {
  if (!v) return null;
  if (typeof v === "string") return v;
  if (typeof v === "object" && v !== null && "toDate" in v) {
    try {
      return (v as { toDate: () => Date }).toDate().toISOString();
    } catch {
      return null;
    }
  }
  return null;
}

/**
 * Agregado seguro para admin. Não lê custos_internos / margens de fornecedor.
 * Prompt 01: enriquece identidades em lote e lista contratações por fornecedor.
 */
export const consultarDashboardFinanceiroAdmin = onCall(
  { region: REGION, timeoutSeconds: 120, cors: true },
  async (request) => {
    const perfil = await exigirUsuarioAutenticado(request.auth?.uid);
    exigirTipo(perfil, ["A"]);

    const data = (request.data ?? {}) as Record<string, unknown>;
    const eixo = texto(data.eixoTemporal ?? data.eixo_temporal) || "data_evento";
    const idFornecedorFiltro = texto(data.idFornecedor ?? data.id_fornecedor);
    const estadoFiltro = texto(data.estado ?? data.status).toLowerCase();
    const inicio = texto(data.periodoInicio ?? data.periodo_inicio);
    const fim = texto(data.periodoFim ?? data.periodo_fim);
    const busca = texto(data.busca ?? data.q).toLowerCase();

    const db = admin.firestore();

    let orcamentos: FirebaseFirestore.Query = db.collection("orcamento");
    if (idFornecedorFiltro) {
      orcamentos = orcamentos.where("id_fornecedor", "==", idFornecedorFiltro);
    }
    const [orcSnap, polSnap, comSnap] = await Promise.all([
      orcamentos.limit(LIMITE_ORCAMENTOS).get(),
      db.collection("plataforma_comissao_politicas").where("ativa", "==", true).limit(1).select().get(),
      db.collection("plataforma_comissao_obrigacoes").limit(500)
        .select("status", "valor_original.centavos", "valor_ajustes_centavos",
          "valor_liquidado.centavos", "vencimento_em", "id_evento").get(),
    ]);
    const truncado = orcSnap.size >= LIMITE_ORCAMENTOS;

    type OrcItem = {
      id: string;
      data: Record<string, unknown>;
      contratado: boolean;
      vals: ReturnType<typeof centavosDeOrcamento>;
      dataEvento: string | null;
      dataContrato: string | null;
    };

    const itens: OrcItem[] = [];
    for (const doc of orcSnap.docs) {
      const d = doc.data() as Record<string, unknown>;
      const idEvento = texto(d.id_evento);
      if (!idEvento) continue;
      const status = texto(d.status).toLowerCase();
      const contratoMap =
        d.contrato_financeiro && typeof d.contrato_financeiro === "object"
          ? (d.contrato_financeiro as { estado_comercial?: string })
          : null;
      const contratado: boolean =
        d.orcamento_fechado === true ||
        status === "fechado" ||
        status === "contratado" ||
        contratoMap?.estado_comercial === "contratado";

      const vals = centavosDeOrcamento(d);
      const dataEvento = parseData(d.data_evento) || parseData(d.data);
      const dataContrato =
        parseData(d.data_cadastro) || parseData(d.data_fechamento);

      if (inicio || fim) {
        const ref = eixo === "data_contratacao" ? dataContrato : dataEvento;
        if (ref) {
          if (inicio && ref < inicio) continue;
          if (fim && ref > fim) continue;
        }
      }
      if (estadoFiltro) {
        if (estadoFiltro === "contratado" && !contratado) continue;
        if (estadoFiltro === "oportunidade" && contratado) continue;
      }

      itens.push({
        id: doc.id,
        data: d,
        contratado,
        vals,
        dataEvento,
        dataContrato,
      });
    }

    const idsEvento = new Set<string>();
    const idsFornecedor = new Set<string>();
    const idsUsuario = new Set<string>();
    for (const it of itens) {
      const idEvento = texto(it.data.id_evento);
      if (idEvento) idsEvento.add(idEvento);
      const idForn = texto(it.data.id_fornecedor);
      if (idForn) idsFornecedor.add(idForn);
      const idSol = texto(it.data.id_solicitante);
      if (idSol) idsUsuario.add(idSol);
    }

    const [eventos, fornecedores, usuarios] = await Promise.all([
      carregarMapaDocs(db, "evento", idsEvento),
      carregarMapaDocs(db, "fornecedor", idsFornecedor),
      carregarMapaDocs(db, "usuarios", idsUsuario),
    ]);
    const organizadoresRestantes = new Set<string>();
    for (const ev of eventos.values()) {
      const uid = texto(ev.id_usuario) || texto(ev.idUsuario);
      if (uid && !idsUsuario.has(uid)) organizadoresRestantes.add(uid);
    }
    for (const [uid, usuario] of await carregarMapaDocs(db, "usuarios", organizadoresRestantes)) {
      usuarios.set(uid, usuario);
    }

    const fatos: FatoComercial[] = [];
    const linhasContratacao: Array<LinhaContratacaoAdmin & {
      valores_contratacao?: ValoresContratacao;
    }> = [];
    const orcamentosContratados = new Map<string, Record<string, unknown>>();

    for (const it of itens) {
      const d = it.data;
      const idEvento = texto(d.id_evento);
      const evento = eventos.get(idEvento);
      const idOrganizador =
        texto(evento?.id_usuario) || texto(evento?.idUsuario) || "";
      const idSolicitante = texto(d.id_solicitante);
      const idFornecedor = texto(d.id_fornecedor);

      const linha = resolverLinhaContratacao({
        idOrcamento: it.id,
        orcamento: d,
        evento: evento ?? null,
        organizador: idOrganizador ? usuarios.get(idOrganizador) ?? null : null,
        contratante: idSolicitante
          ? usuarios.get(idSolicitante) ?? null
          : idOrganizador
            ? usuarios.get(idOrganizador) ?? null
            : null,
        pagador: idSolicitante
          ? usuarios.get(idSolicitante) ?? null
          : idOrganizador
            ? usuarios.get(idOrganizador) ?? null
            : null,
        fornecedor: idFornecedor ? fornecedores.get(idFornecedor) ?? null : null,
        valorContratadoCentavos: it.vals.contratado,
        pagoCentavos: it.vals.pago,
        contratado: it.contratado,
      });

      if (busca) {
        const hay = [
          linha.nome_evento,
          linha.nome_contratante,
          linha.nome_organizador,
          linha.nome_fornecedor,
          linha.nome_servico,
          linha.id_evento,
          linha.id_orcamento,
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();
        if (!hay.includes(busca)) continue;
      }

      linhasContratacao.push(linha);
      if (linha.contratado) orcamentosContratados.set(it.id, d);

      fatos.push({
        idEvento,
        idOrcamento: it.id,
        idNecessidade: texto(d.id_necessidade) || texto(d.id_cotacao) || null,
        idFornecedor: idFornecedor || null,
        idServico:
          texto(d.id_servico_fornecido) || texto(d.id_servico) || null,
        contratado: it.contratado,
        valorOportunidadeCentavos: it.vals.oportunidade,
        valorContratadoCentavos: it.vals.contratado,
        pagoCentavos: it.vals.pago,
        alternativaAtiva: d.alternativa_ativa !== false ? true : false,
        dataEvento: it.dataEvento,
        dataContratacao: it.dataContrato,
        statusEvento: texto(d.status_evento) || texto(d.status) || null,
        consultaPagamentoCompleta: it.vals.pagoCompleto || !it.contratado,
      });
    }

    const idsContratos = [...new Set(linhasContratacao
      .filter((linha) => linha.contratado)
      .map((linha) => linha.id_contrato))];
    const [obrigacoesPorContrato, repassesPorContrato] = await Promise.all([
      lerPorContrato(db.collection("plataforma_comissao_obrigacoes"), idsContratos, [
        "id_evento", "id_fornecedor", "base_elegivel", "status", "politica_aplicada",
        "valor_original", "valor_ajustes_centavos", "valor_liquidado",
        "liquidado_por_retencao_repasse_centavos", "vencimento_em",
      ]),
      lerPorContrato(db.collection(COL_REPASSES), idsContratos, [
        "id_evento", "id_fornecedor", "estado", "valor_centavos", "confirmado_em",
      ]),
    ]);
    for (const linha of linhasContratacao) {
      const orcamento = orcamentosContratados.get(linha.id_orcamento);
      if (!orcamento) continue;
      const obrigacoes = obrigacoesPorContrato.get(linha.id_contrato) ?? [];
      const divisao = divisaoContrato(orcamento, obrigacoes);
      const obrigacao = divisao ? obrigacoes[0] : null;
      const absorvida = divisao?.pagadorComissao === "plataforma_absorve";
      const recebido = obrigacao?.valor_liquidado?.centavos ?? 0;
      const saldoComissao = (divisao?.comissaoCentavos ?? 0) - recebido;
      let repasseConfirmado = 0;
      let ultimoRepasse: string | null = null;
      for (const repasse of repassesPorContrato.get(linha.id_contrato) ?? []) {
        if (repasse.estado !== "confirmado" || repasse.id_evento !== linha.id_evento ||
            repasse.id_fornecedor !== linha.id_fornecedor ||
            !Number.isSafeInteger(repasse.valor_centavos) || repasse.valor_centavos < 0) continue;
        repasseConfirmado += repasse.valor_centavos;
        const confirmadoEm = parseData(repasse.confirmado_em);
        if (confirmadoEm && (!ultimoRepasse || confirmadoEm > ultimoRepasse)) {
          ultimoRepasse = confirmadoEm;
        }
      }
      linha.valores_contratacao = {
        liquido_fornecedor_centavos: divisao?.direitoFornecedorCentavos ?? null,
        comissao_centavos: divisao?.comissaoCentavos ?? null,
        comissao_absorvida: absorvida,
        comissao_recebida_centavos: divisao ? recebido : null,
        vencimento_comissao: !absorvida && saldoComissao > 0
          ? parseData(obrigacao?.vencimento_em)
          : null,
        repasse_confirmado_centavos: repasseConfirmado,
        ultimo_repasse_confirmado_em: ultimoRepasse,
      };
    }

    // Concilia pagamentos parciais (amostra limitada).
    const incompletos = fatos.filter(
      (f) => f.contratado && f.consultaPagamentoCompleta === false,
    );
    const amostra = incompletos.slice(0, 40);
    await Promise.all(
      amostra.map(async (f) => {
        const [liq, gastos] = await Promise.all([
          db
            .collection("orcamento")
            .doc(f.idOrcamento)
            .collection("liquidacoes")
            .limit(50)
            .get()
            .catch(() => null),
          db
            .collection("orcamento")
            .doc(f.idOrcamento)
            .collection("orcamento_gasto")
            .limit(50)
            .get()
            .catch(() => null),
        ]);
        let pago = 0;
        if (liq && !liq.empty) {
          for (const l of liq.docs) {
            const ld = l.data();
            const c = ld.valor?.centavos ?? ld.valor_centavos;
            if (typeof c === "number") pago += c;
            else if (typeof ld.valor === "number") {
              pago += Math.round(ld.valor * 100);
            }
          }
          f.pagoCentavos = pago;
          f.consultaPagamentoCompleta = true;
          const linha = linhasContratacao.find(
            (x) => x.id_orcamento === f.idOrcamento,
          );
          if (linha) linha.pago_centavos = pago;
        } else if (gastos && !gastos.empty) {
          for (const gdoc of gastos.docs) {
            const g = gdoc.data();
            if (typeof g.pago === "number") pago += Math.round(g.pago * 100);
          }
          f.pagoCentavos = pago;
          f.consultaPagamentoCompleta = true;
          const linha = linhasContratacao.find(
            (x) => x.id_orcamento === f.idOrcamento,
          );
          if (linha) linha.pago_centavos = pago;
        }
      }),
    );

    const comissoes: FatoComissao[] = comSnap.docs.map((d) => {
      const x = d.data();
      return {
        id: d.id,
        status: String(x.status ?? "gerada"),
        valorOriginalCentavos: Number(x.valor_original?.centavos ?? 0),
        valorAjustesCentavos: Number(x.valor_ajustes_centavos ?? 0),
        valorLiquidadoCentavos: Number(x.valor_liquidado?.centavos ?? 0),
        vencimento: x.vencimento_em ? String(x.vencimento_em) : null,
        idEvento: x.id_evento ? String(x.id_evento) : null,
      };
    });

    const despesasRaw =
      data.despesasPlataformaCentavos ?? data.despesas_plataforma_centavos;
    const despesas =
      typeof despesasRaw === "number" && Number.isInteger(despesasRaw)
        ? despesasRaw
        : null;

    const dash = agregarDashboardAdmin({
      fatos,
      comissoes,
      politicaComissaoAtiva: !polSnap.empty,
      despesasPlataformaCentavos: despesas,
      eixoTemporal: eixo,
    });

    // Enriquece linhas de evento com nomes (mesmo organizador; contratos listados).
    const linhasEventoEnriquecidas = (dash.linhasEvento as Array<Record<string, unknown>>).map(
      (linha) => {
        const idEvento = String(linha.id_evento ?? "");
        const contratosDoEvento = linhasContratacao.filter(
          (c) => c.id_evento === idEvento,
        );
        const primeiro = contratosDoEvento[0];
        return {
          ...linha,
          nome_evento: primeiro?.nome_evento ?? null,
          nome_organizador: primeiro?.nome_organizador ?? null,
          id_organizador: primeiro?.id_organizador ?? null,
          qtd_identidade_incompleta: contratosDoEvento.filter(
            (c) => c.identidade_incompleta,
          ).length,
          contratacoes: contratosDoEvento.map((c) => ({
            id_contrato: c.id_contrato,
            id_orcamento: c.id_orcamento,
            nome_fornecedor: c.nome_fornecedor,
            nome_servico: c.nome_servico,
            nome_contratante: c.nome_contratante,
            estado_comercial: c.estado_comercial,
            estado_execucao: c.estado_execucao,
            estado_execucao_rotulo: rotuloEstadoExecucao(c.estado_execucao),
            contratado: c.contratado,
            valor_contratado_centavos: c.valor_contratado_centavos,
            pago_centavos: c.pago_centavos,
            identidade_incompleta: c.identidade_incompleta,
            pendencias_identificacao: c.pendencias_identificacao,
            perfil_atual_separado: c.perfil_atual_separado,
            nome_fornecedor_atual: c.nome_fornecedor_atual,
          })),
        };
      },
    );

    const qtdIdentidadeIncompleta = linhasContratacao.filter(
      (c) => c.identidade_incompleta,
    ).length;

    return {
      ok: true,
      ...dash,
      linhasEvento: linhasEventoEnriquecidas,
      linhas_evento: linhasEventoEnriquecidas,
      linhasContratacao,
      linhas_contratacao: linhasContratacao,
      qtdIdentidadeIncompleta,
      qtd_identidade_incompleta: qtdIdentidadeIncompleta,
      origem_consulta: "consultarDashboardFinanceiroAdmin",
      consistencia: {
        idempotente: true,
        fonte_orcamentos: "orcamento + lote evento/fornecedor/usuarios",
        fonte_comissao: "plataforma_comissao_obrigacoes",
        exclui: ["custos_internos", "margens_fornecedor", "estoque_privado", "dados_bancarios"],
        limite_orcamentos: LIMITE_ORCAMENTOS,
        truncado,
        completo: dash.completo && !truncado,
        reprocessamento: "reexecutar callable; sem backfill de produção",
        identidade:
          "snapshot_aceite preferido; perfil atual separado; pendência sem inventar nome",
      },
      paginacao: {
        limite: LIMITE_ORCAMENTOS,
        retornados: orcSnap.size,
        truncado,
        aviso: truncado
          ? "Consulta limitada aos primeiros 500 orçamentos; não é inventário total."
          : null,
      },
      gerado_em: new Date().toISOString(),
    };
  },
);
